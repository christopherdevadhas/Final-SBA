
export class ProjectDetail {
    projectId:number;
    project:string;
    priority:string;
    startDate:Date;
    endDate:Date;
    manager:string;
    noOfTasks:number;
    status:string;
}

