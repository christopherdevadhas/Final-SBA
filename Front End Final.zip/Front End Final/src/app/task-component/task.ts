
export class TaskDetail {
    taskId:number;
    task:string;
    startDate:Date;
    endDate:Date;
    priority:string;
    status:string;
    projectName:string;
    parentTaskName:string;
    userName:string;
}

