
export class TaskDetail {
    taskId:number;
    task:string;
    startDate:string;
    endDate:string;
    priority:string;
    status:string;
    projectName:string;
    parentTaskName:string;
    userName:string;
}

