
export class ProjectDetail {
    projectId:number;
    project:string;
    priority:string;
    startDate:string;
    endDate:string;
    manager:string;
    noOfTasks:number;
    status:string;
}

