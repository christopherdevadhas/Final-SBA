
export class UserDetail {
    userId: number;
    employeeId: number;
    firstName: string;
    lastName: string;
}

